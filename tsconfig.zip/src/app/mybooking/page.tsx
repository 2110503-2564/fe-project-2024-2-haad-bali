'use client'
import BookingList from "@/components/BookingList"

export default function mybookingPage(){
        return (
                <main>
                        <BookingList></BookingList>
                </main>
        )
}