import matchers from '@testing-library/jest-dom/matchers'

export { default } from 'next-auth/middleware'

export const config = {
        matcher: ["/reservations/manage"]
}